# Security Policy

The project is pre-1.0 and not yet approved for executing untrusted source code. Please report suspected vulnerabilities privately to the project owner rather than opening a public issue. Include affected versions, reproduction steps, impact, and any suggested mitigation.

The parser, checker, runtime, package tooling, bytecode verifier, native interface, JIT, and registry are security boundaries. Releases will publish supported versions and a private reporting address before public distribution.

